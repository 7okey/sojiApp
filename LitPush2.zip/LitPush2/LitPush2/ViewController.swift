//
//  ViewController.swift
//  LitPush2
//
//  Created by タルタル on 2019/12/18.
//  Copyright © 2019年 タルタル. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var taskLAbel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func settingButtonAction(_ sender: Any) {
        performSegue(withIdentifier: "goSetting", sender: nil)
    }
    
    @IBAction func doneButtonAction(_ sender: Any) {
    }
    @IBAction func yetButtonAction(_ sender: Any) {
    }
}

