//
//  Task.swift
//  firebaseSample
//
//  Created by タルタル on 2020/01/27.
//  Copyright © 2020年 タルタル. All rights reserved.
//

import Foundation
import UIKit
import Firebase

struct Task: Codable{
   // var alert :String = ""
    var id :Int = 0
    var last : String = ""
    var name :String = ""
    var notes:String = ""
    var period:Int = 0
    var nextDay:String = ""
    //Dictionaryに変換する
    var toDictionary:[String:Any]{
        return[
            "name" : name,
           // "alert": alert,
            "id": id,
            "last": last,
            "notes": notes,
            "period":period,
            "nextDay":nextDay
        ]
    }
    //Dictionaryから自分自身に代入する。
    mutating func setFromDictionary(_dictionary:[String:Any])
    {
      //  alert = _dictionary["alert"]as? String ?? ""
        id = _dictionary["id"]as? Int ?? 0
        last = _dictionary["last"]as? String ?? ""
        name = _dictionary["name"] as? String ?? ""
        notes = _dictionary["notes"] as? String ?? ""
        period = _dictionary["period"] as? Int ?? 0
        nextDay = _dictionary["nextDay"] as? String ?? ""
    }
}//structの後ろのカッコ
/*enum DisplayMode {
    case insert
    case update
}*/
