//
//  SecondViewController.swift
//  firebaseSample
//
//  Created by タルタル on 2020/01/26.
//  Copyright © 2020年 タルタル. All rights reserved.
//

import UIKit
import Firebase

class SecondViewController: UIViewController,UITableViewDataSource, UITableViewDelegate{
    
    //バーボタンアイテムの宣言
    var addBarButtonItem:UIBarButtonItem! // ＋ボタン
    

    @IBOutlet weak var tasksTableView: UITableView!
    var tasks:[Task]!
    var keys :[String]!
    override func viewDidLoad() {
        super.viewDidLoad()
        tasksTableView.dataSource =  self
        tasksTableView.delegate = self
        // Do any additional setup after loading the view.
        // タイトルをセット
        self.navigationItem.title = "掃除一覧"
        //バーボタンアイテムの初期化
        addBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addBarButtonTapped(_:)))
        //バーボタンアイテムの追加
        self.navigationItem.rightBarButtonItem = addBarButtonItem
        // 左ボタン配置時に戻るボタンを残すかどうかのフラグ
      //  self.navigationItem.leftItemsSupplementBackButton = true
        
    }//viewDidLoadの後ろのカッコ
    // ④アクションメソッド
    // ”＋”（追加）ボタンが押された時の処理
    @objc func addBarButtonTapped(_ sender: UIBarButtonItem) {
        let settingTasksViewController = self.storyboard?.instantiateViewController(withIdentifier: "SettingTasksViewController") as! SettingTasksViewController
        self.present(settingTasksViewController, animated: true, completion: nil)
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let ref = Database.database().reference()
        ref.child("taskId").observe(.value){(snapshot) in
            //初期化
            self.tasks = []
            self.keys = []
            for data in snapshot.children{
                var fireDictionary: [String:Any] = [:]
                let snapData = data as! DataSnapshot
              if let dictionarySnapData = snapData.value as? [String:AnyObject]{
               //     let alert = dictionarySnapData["alert"] as? String
                    let id = dictionarySnapData["id"] as? Int
                    let last = dictionarySnapData["last"] as? String
                    let name = dictionarySnapData["name"] as? String
                    let period = dictionarySnapData["period"] as? Int
                    let nextDay = dictionarySnapData["nextDay"] as? String
                //fireDictionaryにセット
             //   fireDictionary.updateValue(alert!, forKey: "alert")
                fireDictionary.updateValue(id!, forKey: "id")
                fireDictionary.updateValue(last!, forKey: "last")
                fireDictionary.updateValue(name!, forKey: "name")
                fireDictionary.updateValue(period!, forKey: "period")
                fireDictionary.updateValue(nextDay!, forKey: "nextDay")
                    
                
               
           //     print(snapData.value)
                //Keyを取得して格納する。
                let key:String = (data as AnyObject).key
                self.keys.append(key)
                var task = Task()
                //取得した内容をTask型にセット
                task.setFromDictionary(_dictionary: fireDictionary)
                // Taskリストに追加
                self.tasks.append(task)
                }//dictionarySnapDataの後ろのカッコ
            }//forのカッコ
            //全てTaskリストに格納したら、Tableviewを更新する。
            self.tasksTableView.reloadData()
        }//snapshotの後ろカッコ
    }//viewWillApperのカッコ
    
    // MARK: - TableViewMethod
    //セルの個数
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard let _tasks = tasks else { return 0 }
        return _tasks.count
    }//tableViewの後ろのカッコ(セルの個数)
    
    //セルに値をセット
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =  tasksTableView.dequeueReusableCell(withIdentifier: "taskTableCell", for: indexPath)
        let task = tasks[indexPath.row]
      //  let nameLabel = cell.viewWithTag(1) as! UILabel
        //    nameLabel.text = task.name
        
        cell.textLabel?.text = task.name
        return cell
    }//tableViewの後ろのカッコ（セルに値をセット）
    
    //セルタップ時
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath as IndexPath, animated: true)
    }
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
