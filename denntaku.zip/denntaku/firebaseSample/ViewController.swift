//
//  ViewController.swift
//  firebaseSample
//
//  Created by タルタル on 2019/12/18.
//  Copyright © 2019年 タルタル. All rights reserved.
//

import UIKit
import Firebase

class ViewController: UIViewController {

    @IBOutlet weak var emailTextField: UITextField!
    
    @IBOutlet weak var passwordTextFiled: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func registerButtonAction(_ sender: Any) {
        let userEmail =  emailTextField.text
        let userPassword = passwordTextFiled.text
        //未入力欄確認
        if(userEmail == "" || userPassword == "" ){
            //アラートメッセージ
            displayMyAlertMessage(userMessage: "全てのフォームに入力してください。")
            return
        }
        // データ登録
        UserDefaults.standard.set(userEmail, forKey:"userEmail")
        UserDefaults.standard.set(userPassword, forKey:"userPassword")
        //UserDefaults.standard.synchronize();
        
        // メッセージアラートなど
        let myAlert = UIAlertController(title:"Alert", message: "登録完了!!", preferredStyle:  UIAlertController.Style.alert)
        let okAction = UIAlertAction(title:"OK", style: UIAlertAction.Style.default){
            action in self.dismiss(animated: true, completion:nil)
        }
        myAlert.addAction(okAction)
        self.present(myAlert, animated:true,completion:nil)
        //firebseに登録
        let email = UserDefaults.standard.value(forKey: "userEmail")
        let pass = UserDefaults.standard.value(forKey: "userPassword")
        Auth.auth().createUser(withEmail: email as! String, password: pass as! String,completion: {(user, error) in
            //エラー処理
            if error != nil{
                print(error!)
                return
            }
            //成功した時
            
        })
        
        
        
    }
    
    func displayMyAlertMessage(userMessage: String){
        
        let myAlert = UIAlertController(title:"Alert", message: userMessage, preferredStyle:  UIAlertController.Style.alert)
        let okAction = UIAlertAction(title:"OK", style: UIAlertAction.Style.default, handler:nil)
        myAlert.addAction(okAction);
        self.present(myAlert,animated:true, completion:nil)
        
    }
    
    
    
    }
    
    
    

    

    
    



