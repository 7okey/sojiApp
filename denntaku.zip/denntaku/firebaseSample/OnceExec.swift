//
//  OnceExec.swift
//  firebaseSample
//
//  Created by タルタル on 2020/02/12.
//  Copyright © 2020年 タルタル. All rights reserved.
//

import Foundation

class OnceExec {
    var isExec = false
    func call(onceExec: ()->()){
        if !isExec {
            onceExec()
            isExec = true
        }
    }
}
