//
//  SettingTasksViewController.swift
//  firebaseSample
//
//  Created by タルタル on 2020/01/04.
//  Copyright © 2020年 タルタル. All rights reserved.
//

import UIKit
import Firebase
//時刻のDate型を変えるクラス
class DateUtils {
    class func dateFromString(string: String, format: String) -> Date {
        let formatter: DateFormatter = DateFormatter()
        formatter.calendar = Calendar(identifier: .gregorian)
        formatter.dateFormat = format
        return formatter.date(from: string)!
    }
    
    class func stringFromDate(date: Date, format: String) -> String {
        let formatter: DateFormatter = DateFormatter()
        formatter.calendar = Calendar(identifier: .gregorian)
        formatter.dateFormat = format
        return formatter.string(from: date)
    }
}

class SettingTasksViewController: UIViewController,UITextViewDelegate {
    @IBOutlet weak var taskNameTextField: UITextField!
    @IBOutlet weak var periodNumberTextField: UITextField!
    @IBOutlet weak var noteTextField: UITextView!
    
    
    var pushCountNumber:Int! = 0
    var alert:String?
    var last : Date = Date()
    var taskSettingsName :String?
    var notes :String?
    var period : Int?
    var localDate : Date!
    var newId:Int! = 0
 //   var localDate: Date?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // タイトルをセット
        self.navigationItem.title = "登録"
        // Do any additional setup after loading the view.
        noteTextField.delegate = self
    }
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        
        if (text == "\n") {
            //あなたのテキストフィールド
             noteTextField.resignFirstResponder()
            return false
        }
        return true
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        //taskIdMaxのDBからの読み取り（1回目:画面遷移後）
    Database.database().reference().child("taskMax").observeSingleEvent(of: .value, with:{(snapshot) in
    if let data = snapshot.value as? [String:AnyObject]{
    let taskIdMax = data["taskIdMax"] as? Int
    print(taskIdMax!)
    self.pushCountNumber = taskIdMax! + 1
    print(self.pushCountNumber!)
    
    }
    }, withCancel: nil)
        }
    @IBAction func taskNameSettingsButton(_ sender: Any) {
        if taskNameTextField.text != nil{
             taskSettingsName = taskNameTextField.text
        }else{
            print("taskNameTextField.textはnil。")
        }
        //notes
        if  noteTextField.text != nil{
         notes = noteTextField.text
        }else{
            print("noteTextField.textはnill。")
        }
        //未入力欄確認
        if(taskSettingsName == "" ){
            //アラートメッセージ
            displayMyAlertMessage(userMessage: "全てのフォームに入力してください。")
            return
            
        }
        //日付を取得するプログラム
        //システムのタイムゾーン
        let timezone: TimeZone = TimeZone.current
        //ローカルの日時
         localDate = Date(timeIntervalSinceNow: Double (timezone.secondsFromGMT()))
        print(localDate!)
        //localDateをString化してDBに送る。
        let localDateString = DateUtils.stringFromDate(date: localDate!, format: "yyyy年MM月dd日 HH時mm分ss秒 ")
        print(localDateString)
        //period(周期日数)を数字（Int）で設定し保存する。
        if periodNumberTextField.text != nil{
        let periodSettingsNumber = periodNumberTextField.text
         period = Int(periodSettingsNumber!)
        }else{
            print("periodNumberTextField.textはnil。")
        }
        //「last」の取得（taskIdn内の「last」の読み取り）
      /*  Database.database().reference().child("taskId").child("task\(String(pushCountNumber))").observeSingleEvent(of: .value, with:{(snapshot) in
            if let data = snapshot.value as? [String:AnyObject]{


                let lastString = (data["last"] as? String)!
                self.last = DateUtils.dateFromString(string: lastString, format: "yyyy/MM/dd HH:mm:ss Z")
                
                print(self.last)
                
            }
        }, withCancel: nil)
    
        //Int型の（now - last）の計算（日付）
        let lastDate = self.last
        let now = localDate!
        let lastDateStartOfDay = Calendar.current.startOfDay(for: lastDate)
        let nowStartOfDay = Calendar.current.startOfDay(for: now)
        let elapsedDays = Calendar.current.dateComponents([.day], from: lastDateStartOfDay, to: nowStartOfDay).day!
        print("(now - last)は\(String(elapsedDays))")
        if elapsedDays >= period! {
            print("掃除が必要です。")
            self.alert = "掃除が必要です。"
            }else{
            print("まだ、大丈夫です。")
            self.alert = "まだ、大丈夫です。"
            }*/
         let now = localDate!
        //NextDayを算出する。
        let modifiedDate = Calendar.current.date(byAdding: .day, value: period!, to: now)!
        print("modifiedDate : \(modifiedDate)")
        //modifiedDateをString化する
        let modifiedDateString = "\(modifiedDate)"
    //taskIdMaxのDBからの読み取り（2回目）
        Database.database().reference().child("taskMax").observeSingleEvent(of: .value, with:{(snapshot) in
            if let data = snapshot.value as? [String:AnyObject]{
                let taskIdMax = data["taskIdMax"] as? Int
                print(taskIdMax!)
                self.pushCountNumber = taskIdMax! + 1
                print(self.pushCountNumber!)
                
            }
        }, withCancel: nil)
    
        newId = self.pushCountNumber
        //データ登録
        UserDefaults.standard.set(taskSettingsName, forKey:"taskSettingsName")
        UserDefaults.standard.set(self.pushCountNumber, forKey:"taskIdMax")
        //UserDefaults.standard.synchronize();
        
        //保存するデータ(タスク数)
        let values = [ "taskIdMax": newId ] as [String : Any]
        Database.database().reference().child("taskMax").updateChildValues(values, withCompletionBlock: { (error, reference) in
            //エラー処理
            if error != nil{
                print(error!)
                return
            }
            //成功した時
            print("送信成功")
        })
        
        //保存するデータ(ここのタスク内容)
        let taskValues = ["id": newId! ,"name": taskSettingsName!,"period": period! ,"last": localDateString ,"nextDay": modifiedDateString ,"notes": notes!] as [String : Any]
        Database.database().reference().child("taskId").child("task\(String(newId))").updateChildValues(taskValues, withCompletionBlock: { (error, reference) in
            //エラー処理
            if error != nil{
                print(error!)
                return
            }
            //成功した時
            print("タスク内容の送信成功")
        })
        
        // 登録後 前画面に戻る
       self.performSegue(withIdentifier: "toSecond", sender: nil)
        //self.navigationController?.popViewController(animated: true)
    }//ボタンの後ろかっこ
    

    func displayMyAlertMessage(userMessage: String){
        
        let myAlert = UIAlertController(title:"Alert", message: userMessage, preferredStyle:  UIAlertController.Style.alert)
        let okAction = UIAlertAction(title:"OK", style: UIAlertAction.Style.default, handler:nil)
        myAlert.addAction(okAction);
        self.present(myAlert,animated:true, completion:nil)
        
    }

}//viewControllerの後ろのかっこ
