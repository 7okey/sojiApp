//
//  FirstViewController.swift
//  firebaseSample
//
//  Created by タルタル on 2020/01/26.
//  Copyright © 2020年 タルタル. All rights reserved.
//

import UIKit
import Firebase


class FirstViewController: UIViewController {
   
    @IBOutlet weak var taskLabel: UILabel!
    var missions:[Mission]!
    var missionsToCount:Int =  0
    var missionsCount:Int = 0
    var keys :[String]!
     var todayTasks:[String] = []
     var todayTasksPeriod:[Int] = []
     var todayTasksId:[Int] = []
  //  var todayTasksAlert:[String] = []
    var todayTasksLast:[String] = []
    var todayTasksNextday:[String] = []
    var todayTasksNotes:[String] = []
    var count = 0
    var onceExec = OnceExec()
    var stopTask :Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }//viewDidLoadのかっこ
    //今日の日付を取得
    //システムのタイムゾーン
    let timezone: TimeZone = TimeZone.current
    //ローカルの日時
    lazy var localDate = Date(timeIntervalSinceNow: Double (timezone.secondsFromGMT()))
    
    @IBAction func startButton(_ sender: Any) {
        let ref = Database.database().reference()
        ref.child("taskId").observe(.value){(snapshot) in
            self.missionsToCount = Int(snapshot.childrenCount - 1)
            self.missionsCount = Int(snapshot.childrenCount)
            print("missionsToCountの数\(String(self.missionsToCount))")
            //viewWillApperの中身が動かないようにする。
            if self.count != self.missionsCount{
                //初期化
                self.missions = []
                self.keys = []
                for data in snapshot.children{
                    var fireDictionary: [String:Any] = [:]
                    let snapData = data as! DataSnapshot
                    if let dictionarySnapData = snapData.value as? [String:AnyObject]{
                        //    let alert = dictionarySnapData["alert"] as? String
                        let id = dictionarySnapData["id"] as? Int
                        let last = dictionarySnapData["last"] as? String
                        let name = dictionarySnapData["name"] as? String
                        let period = dictionarySnapData["period"] as? Int
                        let nextDay = dictionarySnapData["nextDay"] as? String
                        let notes = dictionarySnapData["notes"] as? String
                        //fireDictionaryにセット
                        //   fireDictionary.updateValue(alert!, forKey: "alert")
                        fireDictionary.updateValue(id!, forKey: "id")
                        fireDictionary.updateValue(last!, forKey: "last")
                        fireDictionary.updateValue(name!, forKey: "name")
                        fireDictionary.updateValue(period!, forKey: "period")
                        fireDictionary.updateValue(nextDay!, forKey: "nextDay")
                        fireDictionary.updateValue(notes!, forKey: "notes")
                        
                        print(snapshot.children)
                        
                        //Keyを取得して格納する。
                        let key:String = (data as AnyObject).key
                        self.keys.append(key)
                        var mission = Mission()
                        //取得した内容をTask型にセット
                        mission.setFromDictionary(_dictionary: fireDictionary)
                        // Taskリストに追加
                        self.missions.append(mission)
                        print("forの繰り返し回数：\(String(self.count))目です。")
                        let missionNumber = self.missions[self.count]
                        print(missionNumber.name)
                        print("missionsの数：\(String(self.missions.count))")
                        
                        
                        let nextDays = DateUtils.dateFromString(string: missionNumber.nextDay, format: "yyyy/MM/dd HH:mm:ss Z")
                        print(nextDays)
                        print(self.localDate)
                        if (self.localDate == nextDays || self.localDate > nextDays ){
                            print("appendしました。")
                            //追加(name)
                            self.todayTasks.append(missionNumber.name)
                            print("todayTasks\(self.todayTasks[0])")
                            //追加(Period)
                            self.todayTasksPeriod.append(missionNumber.period)
                            //追加(Id)
                            self.todayTasksId.append(missionNumber.id)
                            //追加(その他)
                            // self.todayTasksAlert.append(missionNumber.alert)
                            self.todayTasksLast.append(missionNumber.last)
                            self.todayTasksNextday.append(missionNumber.nextDay)
                            self.todayTasksNotes.append(missionNumber.notes)
                            //count数の制限
                         //   self.count = self.count + 1
                             if self.count != self.missionsToCount{
                                self.stopTask = self.count
                             self.count = self.count + 1
                                
                             }else{ self.count = self.count + 1 }//countの数制限
                        }else{
                            
                            print("count制限\(self.todayTasks[self.stopTask])")
                            self.count = self.count + 1
                            
                            
                        }///ifの後ろ
                    }//dictionarySnapDataの後ろのカッコ
                    //今日のタスクのひ表示
                    self.taskLabel.text = self.todayTasks[0]
                }//forのカッコ
                
            }else{ print("動かないようにした！")
                return }//viewWillApperの中身が動かないようにする。の後ろのかっこ
            
            
        }//snapshotの後ろカッコ
        
    }
   /* override func viewWillAppear(_ animated: Bool) {
        onceExec.call {
            //一度だけ実行したい処理メソッド
        super.viewWillAppear(animated)
       
        let ref = Database.database().reference()
        ref.child("taskId").observe(.value){(snapshot) in
            self.missionsCount = Int(snapshot.childrenCount)
            print("missionsCountの数\(String(self.missionsCount))")
            //viewWillApperの中身が動かないようにする。
            if self.count != self.missionsCount{
            //初期化
            self.missions = []
            self.keys = []
            for data in snapshot.children{
                var fireDictionary: [String:Any] = [:]
                let snapData = data as! DataSnapshot
                if let dictionarySnapData = snapData.value as? [String:AnyObject]{
                //    let alert = dictionarySnapData["alert"] as? String
                    let id = dictionarySnapData["id"] as? Int
                    let last = dictionarySnapData["last"] as? String
                    let name = dictionarySnapData["name"] as? String
                    let period = dictionarySnapData["period"] as? Int
                    let nextDay = dictionarySnapData["nextDay"] as? String
                    let notes = dictionarySnapData["notes"] as? String
                    //fireDictionaryにセット
                 //   fireDictionary.updateValue(alert!, forKey: "alert")
                    fireDictionary.updateValue(id!, forKey: "id")
                    fireDictionary.updateValue(last!, forKey: "last")
                    fireDictionary.updateValue(name!, forKey: "name")
                    fireDictionary.updateValue(period!, forKey: "period")
                    fireDictionary.updateValue(nextDay!, forKey: "nextDay")
                    fireDictionary.updateValue(notes!, forKey: "notes")
                    
                   print(snapshot.children)
                    
                    //Keyを取得して格納する。
                    let key:String = (data as AnyObject).key
                    self.keys.append(key)
                    var mission = Mission()
                    //取得した内容をTask型にセット
                    mission.setFromDictionary(_dictionary: fireDictionary)
                    // Taskリストに追加
                    self.missions.append(mission)
                    print("forの繰り返し回数：\(String(self.count))目です。")
                    let missionNumber = self.missions[self.count]
                    print(missionNumber.name)
                    print("missionsの数：\(String(self.missions.count))")
                   
                    
                    let nextDays = DateUtils.dateFromString(string: missionNumber.nextDay, format: "yyyy/MM/dd HH:mm:ss Z")
                    print(nextDays)
                    print(self.localDate)
                    if (self.localDate == nextDays || self.localDate > nextDays ){
                        print("appendしました。")
                        //追加(name)
                        self.todayTasks.append(missionNumber.name)
                        print("todayTasks\(self.todayTasks[0])")
                        //追加(Period)
                        self.todayTasksPeriod.append(missionNumber.period)
                        //追加(Id)
                        self.todayTasksId.append(missionNumber.id)
                        //追加(その他)
                       // self.todayTasksAlert.append(missionNumber.alert)
                        self.todayTasksLast.append(missionNumber.last)
                        self.todayTasksNextday.append(missionNumber.nextDay)
                        self.todayTasksNotes.append(missionNumber.notes)
                        //count数の制限
                        self.count = self.count + 1
                     /*  if self.count != self.missionsCount{
                        self.count = self.count + 1
                       }else{ return }*///countの数制限
                    }else{
                        print("count制限\(self.todayTasks[1])")
                        return
                        
                    }///ifの後ろ
                }//dictionarySnapDataの後ろのカッコ
                //今日のタスクのひ表示
                self.taskLabel.text = self.todayTasks[0]
            }//forのカッコ
               
          }else{ print("動かないようにした！")
                return }//viewWillApperの中身が動かないようにする。の後ろのかっこ
           
           
        }//snapshotの後ろカッコ
            
        }//oneExecのかっこ
   
    }//viewWillApperのカッコ
   */
       
    
    @IBAction func doneButton(_ sender: Any) {
        if  todayTasks != nil{
            if todayTasks.isEmpty{
                taskLabel.text = "お疲れ様です。"
            }else{
    //（済）タスクの処理
        let modifideDate = Calendar.current.date(byAdding: .day, value: todayTasksPeriod[0], to: self.localDate)!
    //modifideDateをString化
        let modifiedDateString = "\(modifideDate)"
        print("ボタンが押されました。")
        //最新日を更新
            //localDateをString化
        let localDateString = DateUtils.stringFromDate(date: localDate, format: "yyyy年MM月dd日 HH時mm分ss秒 ")
        //保存するデータ
        
        let taskValues = ["id": todayTasksId[0] ,"name":todayTasks[0] ,"period": todayTasksPeriod[0] ,"last": localDateString ,"nextDay": modifiedDateString,"notes": todayTasksNotes[0]] as [String : Any]
        Database.database().reference().child("taskId").child("task\(String(todayTasksId[0]))").setValue(taskValues, withCompletionBlock: { (error, reference) in
            //エラー処理
            if error != nil{
                print(error!)
                return
            }
            //成功した時
            print("タスク内容(nextDay)の送信成功")
        })
       
        //先頭にあった配列の変数の削除
        todayTasks.remove(at:0)
        todayTasksPeriod.remove(at:0)
        todayTasksId.remove(at:0)
        todayTasksNotes.remove(at: 0)
                }//上側のif todayTasks.isEmptyのカッコ
        }else{
            print("Taskありません。")
            return }//上側のif  todayTasks != nilのかっこ
        //次のタスクがあるかどうかの判定
       /* func nilHante(todayTasks: [Bool]?) -> String {
            if todayTasks?.isEmpty ?? true {
                if let todayTasks = todayTasks {
                    taskLabel.text = "お疲れ様です。"
                    return "array.count \(todayTasks.count)"
                } else {
                    taskLabel.text = "お疲れ様です。"
                    return "arrayはnilやん"
                }
            }
            //配列にタスクがある時
            taskLabel.text =  "\(todayTasks![0])"
            return "何かある"
        }
        
        _ = nilHante(todayTasks: [])*/
        //次のタスクがあるかどうかの判定
        if todayTasks != nil{
        if todayTasks.isEmpty{
       
            //配列が空
            taskLabel.text = "お疲れ様です。"
        }else{
            //配列にタスクがある時
            taskLabel.text =  todayTasks[0]
        }
            
        }else{ taskLabel.text = "お疲れ様です。"}//下側のif todayTasks != nil
    }//ボタンの後ろのカッコ
    @IBAction func ichiranButton(_ sender: Any) {
        performSegue(withIdentifier: "goIchiran", sender: nil)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
